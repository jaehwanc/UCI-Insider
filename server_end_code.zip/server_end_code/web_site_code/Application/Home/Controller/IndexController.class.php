<?php
namespace Home\Controller;
use Think\Controller;
use Common\Common\Util;
class IndexController extends Controller {
    public function index(){
    	echo "if you see this, you are lucky";
     }
    

}