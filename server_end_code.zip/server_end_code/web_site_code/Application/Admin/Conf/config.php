<?php

require_once(APP_PATH."Common/Conf/dev_config.php");   // 路径为./Common/Conf/dev/config.php
require_once(APP_PATH."Common/Conf/testing_config.php");  // 路径为./Common/Conf/testing/config.php
require_once(APP_PATH."Common/Conf/online_config.php");  // 路径为./Common/Conf/online/config.php

$env_code=1;   // 1 开发环境;2 测试环境;3 线上环境
$result=array();

switch ($env_code)
{
	case 1:
		$result=$dev_config;
		break;
	case 2:
		$result=$testing_config;
		break;
	case 3:
		$result=$online_config;
		break;
	default:
		$result=$dev_config;
}

return $result;
