<?php
namespace Admin\Controller;
use Think\Controller;
use Common\Common\Util;
use Common\Common\Consts;
use DateTime;
use Common\Common\Firebase;


use Common\Common\Log;

// function cmp($a, $b)
// {
// 	return $a > $b;
// 	//echo "use it";
// 	//return $a['span']>$b['span'];
// }
function cmp($a, $b)
{
	echo "1111";
	if ($a == $b) {
		return 0;
	}
	return ($a < $b) ? -1 : 1;
}

class InsiderController  extends CommonController  {

	

	public static function outPut($errtype, $msg = "", $returndata = array())
	{
		$err_strs = Consts::CODE_DESC;
		if(empty($msg))  $msg = $err_strs[$errtype];
		Controller::ajaxReturn(Controller::objResponse($errtype, $msg, $returndata));
	}
     
     public function index(){
     	echo phpinfo();
    	$input = $this->getPostJson();

       $data["book"] = "this is a case we love";
    	
    	$this->outPut(0, "", $data);
     }
     

     
     function login(){
     	
     	$uri = $_SERVER["REQUEST_URI"];
     	$content =  file_get_contents ("php://input");
     	Log::info(" $uri $content ");
     	 

     	$results = print_r($_POST,true);
  
      	log::info("[login]  $results ");
//      	echo '{"result":0,"message":"success","data":{"token":"b442c7dc4b939e4d6b11d79f3870c32a","name":"Yousong Zhang","classes":[{"id":"648","department":"CSE","code":"46","title":"DATA STRC IMPL&amp;ANLS","professor":"PATTIS, R.","rate":3,"address":"SSLH 100","time":"MWF  11:00-11:50"},{"id":"601","department":"CompSci","code":"225","title":"NXT GEN SRCH SYSTMS","professor":"JAIN, R.","rate":3,"address":"HH 178","time":"TuTh   9:30-10:50"},{"id":"607","department":"CompSci","code":"253","title":"ANALYSIS PROG LANG","professor":"JONES, J.","rate":3,"address":"MSTB 110","time":"TuTh   3:30- 4:50p"}]}}';
//      	exit;
     
     	$input = $this->getPostJson();
     	
     	$uci_id = $input["uci_id"];
     	$passwd = $input["passwd"];
     	
     	
     	$ch = curl_init();
     	$raw = "referer=&return_url=&info_text=&info_url=&submit_type=&ucinetid={$uci_id}&password={$passwd}&login_button=Login";

     	curl_setopt($ch, CURLOPT_URL,            "https://login.uci.edu/ucinetid/webauth" );
     	curl_setopt($ch, CURLOPT_POST,            1);
     	curl_setopt($ch, CURLOPT_POSTFIELDS,     $raw );
     	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
     	//curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain'));
     	curl_setopt($ch, CURLOPT_HEADER, true);
     	
     	 
     	$comment =curl_exec ($ch);

     //	$cookies =  curl_getinfo($ch, CURLINFO_COOKIELIST);
     	//$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
       // $header = substr($response, 0, $header_size);
     //	echo substr($comment, 0,300);
     	$pos = strpos($comment, "ucinetid_auth=");
//     	echo $raw;
//      	echo $comment;
//      	exit;
//      	$token = "";
     	
     	$uci_token_check = substr($comment, $pos+14, 6);
     	$uci_token = substr($comment, $pos+14, 64);
     	
   //  	echo $uci_token_check;
   //  	exit;
     		
     	if($uci_token_check == "no_key"){
     		
     			$this->outPut(1, "user/passwd error");
     			exit;
     		
     	}else{
        		 
     		$user = M('insider_user')->where(['uci_id'=>$uci_id])->find();
     		if(empty($user)){
     			$data['uci_id'] = $uci_id;
     			$time_str =  date('Y-m-d H:i:s', time());
     			$data['create_time'] = $time_str;
     			M('insider_user')->add($data);
     		}
     		
     		
     		$random = mt_rand(10000000, 99999999);  //8 位
     		$token = md5($random);
     		$token = md5($token);   //二次加密
     		
     		$fields["token"] = $token;
     		$fields["update_time"] =  date('Y-m-d H:i:s', time());
     		$fields['uci_token'] = $uci_token;
     		
     		M('insider_user')->where(["uci_id"=>$uci_id])->setField($fields);
     		
     		//$this->outPut(0,"", ["token"=>$token]);
     		
     	}
     	
     	$user = M('insider_user')->where(['uci_id'=>$uci_id])->find();
     	$name = $user['name'];
     	if(empty($name)){
     		$name = $this->load_current_quarter_classes($user);
     		$uci_token = $user['uci_token'];
     		load_quarter_class($uci_token, "16", "S");
     		load_quarter_class($uci_token, "16", "S");
     		load_quarter_class($uci_token, "16", "S");
     		load_quarter_class($uci_token, "16", "S");
     		M('insider_user')->where(["uci_id"=>$uci_id])->setField(["name"=>$name]);
     	}

     	$list = $this->get_current_class($user['id']);
     	
     	$this->outPut(0,"", ["token"=>$token, "name"=>$name, "classes"=>$list]);
//      	echo '{"result":0,"message":"success","data":{"token":"b442c7dc4b939e4d6b11d79f3870c32a","name":"Yousong Zhang","classes":[{"id":"648","department":"CSE","code":"46","title":"DATA STRC IMPL&amp;ANLS","professor":"PATTIS, R.","rate":3,"address":"SSLH 100","time":"MWF  11:00-11:50"},{"id":"601","department":"CompSci","code":"225","title":"NXT GEN SRCH SYSTMS","professor":"JAIN, R.","rate":3,"address":"HH 178","time":"TuTh   9:30-10:50"},{"id":"607","department":"CompSci","code":"253","title":"ANALYSIS PROG LANG","professor":"JONES, J.","rate":3,"address":"MSTB 110","time":"TuTh   3:30- 4:50p"}]}}';
//      	exit;
     }
     
     function quarter(){
     	$user = $this->check_user_token();
     	//$class = $this->class_id_by_code2(20035);
     	$name = $this->load_current_quarter_classes($user);
     	echo $name;
     	exit;
     	//var_dump($user);
     	$list = $this->get_current_class($user['id']);
     	
     	$this->outPut(0,"", ["classes"=>$list]);
     }
     
     function get_current_class($uid){

     	$list = M('myclass')->where(['uid'=>$uid])->select();
     	if(empty($list)) return ;
     	
     	$classes = [];
     	foreach($list as $c){
//      		echo $c['cid'];
//      		exit;
     		$class = $this->get_class_fields($c['cid']);
     		$classes[] = $class;
     		
     	}
     	
     	return $classes;
     }
     
     
     function get_class_fields($cid){
     	$class =  M('class')->where(['id'=>$cid])->find();
     	$data["id"] = $class["id"];
     	$data["department"] = $class["dept"];
     	$data["code"] = $class["code"];
     	$data["title"] = $class["title"];
     	$data["professor"] = $class["teacher"];
     	$data["rate"] = $class['rate'];
     	$data["address"] = $class["room"];
     	$data["time"] = $class["stime"];
     	return $data;
     	
     }
     
     function get_class_fields2($class){
     	$data["id"] = $class["id"];
     	$data["department"] = $class["dept"];
     	$data["code"] = $class["code"];
     	$data["title"] = $class["title"];
     	$data["professor"] = $class["teacher"];
     	$data["rate"] = $class['rate'];
     	$data["address"] = $class["room"];
     	$data["time"] = $class["stime"];
     	return $data;
     
     }
     
     function class_id_by_code2($code2){
     	
     	return M('class')->where(['code2'=>$code2])->find();
     }
     
     function check_user_token(){
     	$input = $this->getPostJson();
     	$token = $input["token"];
     	$user = M('insider_user')->where(['token'=>$token])->find();
     	if(empty($user)){
     		$this->outPut(1, "token error");
     		exit;
     	} 	
     	return $user;
     }
     
     function myeee(){
     	$user = $this->check_user_token();
     	$name = $this->load_current_quarter_classes($user);
     	//echo "this is a test";
     	$list = $this->get_current_class($user['id']);
     	$this->outPut(0,"",  ["classes"=>$list]);
     }
     
     function load_current_quarter_classes($user){
     	
     	$ch = curl_init();
     	
        $cookie = "ucinetid_auth={$user['uci_token']}";

   
        
        $raw ="quarter=W17&submit=Change+Term";
     	
     	
     	 
     	curl_setopt($ch, CURLOPT_URL,            "https://eee.uci.edu/myeee/" );
     	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
     	curl_setopt($ch, CURLOPT_POST,            1);
     	curl_setopt($ch, CURLOPT_POSTFIELDS,     $raw );
     	curl_setopt($ch, CURLOPT_USERAGENT , "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:51.0) Gecko/20100101 Firefox/51.0");
     	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
     	//curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain'));
//      	 var_dump($user);
//      exit;
       
     	$content =curl_exec ($ch);
     	

     	
     	
     	$pos = strpos($content, "logged-in-user");
     	$pos2 = strpos($content, "</span>", $pos);
     	$name = substr($content, $pos+16, $pos2-$pos-16);
     	
     	$pos = strpos($content, "<li class='header'>Student</li>");
     	$pos2 = strpos($content, "<ul", $pos);
     	$text = substr($content, $pos+31, $pos2 - $pos -31-5);
     	
     	$array = explode("href", $text);
     	array_shift($array);
     	$classes = [];
//      	echo "<pre>";
//      	print_r($array);
//      	echo "</pre>";
//      	exit;
     	foreach($array as $v){
     		$pos = strpos($v, ">");
     		$pos2 = strpos($v, "<", $pos);
     		$segment = substr($v, $pos+1, $pos2 -$pos-1);
     	//	echo $segment;
     		$array2 = explode(" ", $segment);
     		$count = count($array2);
     		if($count == 7){
     			$first = array_shift($array2);
     			$data['depart'] = $first." ".$array2[0];
     		}else{
     			$data['depart'] = $array2[0];
     			
     		}
    
     		
     		$data['depart'] = $array2[0];
     		$data['code'] = $array2[1];

     		if(!($data['code'] > 0))continue;
     		if($array2[3] != "LEC")continue;
     		$codes2 = str_replace("(","",$array2[5]);
			$codes2 = str_replace(")","",$codes2);
     		$data['code2'] = $codes2;
     		$data['uid'] = $user['id'];
     		
     		$data['quarter'] = "20171";
     		$data['create_time'] = date('Y-m-d H:i:s', time());
     		
     		$class = $this->class_id_by_code2($data['code2']);
     		$data['cid'] = $class['id'];
     		
     		
     	//	$classes[] =  $data;
     	//echo "###".$user['id']  ."  ".  $codes2."###\n";
     	
     		$class = M('myclass')->where(["uid"=>$user['id'], "code2"=>$codes2])->find();
     		
     		if(empty($class)){
     			M('myclass')->add($data);
     		}else{
     			//M('myclass')->add($data);
     		}
     		
     		
     	}
       
     	return $name;
     }
     
     
     function load_quarter_class($uci_token, $year, $quarter){
     	$ch = curl_init();
     	
     	$cookie = "ucinetid_auth={$uci_token}";
     	
     	 
     	
     	$raw ="quarter={$quarter}{$year}&submit=Change+Term";
     	
     	
     	 
     	curl_setopt($ch, CURLOPT_URL,            "https://eee.uci.edu/myeee/" );
     	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
     	curl_setopt($ch, CURLOPT_POST,            1);
     	curl_setopt($ch, CURLOPT_POSTFIELDS,     $raw );
     	curl_setopt($ch, CURLOPT_USERAGENT , "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:51.0) Gecko/20100101 Firefox/51.0");
     	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
     	//curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain'));
     	//      	 var_dump($user);
     	//      exit;
     	 
     	$content =curl_exec ($ch);
     	
     	
     	
     	
     	$pos = strpos($content, "logged-in-user");
     	$pos2 = strpos($content, "</span>", $pos);
     	$name = substr($content, $pos+16, $pos2-$pos-16);
     	
     	$pos = strpos($content, "<li class='header'>Student</li>");
     	$pos2 = strpos($content, "<ul", $pos);
     	$text = substr($content, $pos+31, $pos2 - $pos -31-5);
     	
     	$array = explode("href", $text);
     	array_shift($array);
     	$classes = [];
     	//      	echo "<pre>";
     	//      	print_r($array);
     	//      	echo "</pre>";
     	//      	exit;
     	foreach($array as $v){
     		$pos = strpos($v, ">");
     		$pos2 = strpos($v, "<", $pos);
     		$segment = substr($v, $pos+1, $pos2 -$pos-1);
     		//	echo $segment;
     		$array2 = explode(" ", $segment);
     		$count = count($array2);
     		if($count == 7){
     			$first = array_shift($array2);
     			$data['depart'] = $first." ".$array2[0];
     		}else{
     			$data['depart'] = $array2[0];
     	
     		}
     	
     		 
     		$data['depart'] = $array2[0];
     		$data['code'] = $array2[1];
     	
     		if(!($data['code'] > 0))continue;
     		if($array2[3] != "LEC")continue;
     		$codes2 = str_replace("(","",$array2[5]);
     		$codes2 = str_replace(")","",$codes2);
     		$data['code2'] = $codes2;
     		$data['uid'] = $user['id'];
     		 
     		$data['quarter'] = "20171";
     		$data['create_time'] = date('Y-m-d H:i:s', time());
     		 
     		$class = $this->class_id_by_code2($data['code2']);
     		$data['cid'] = $class['id'];
     		 
     		 
     		//	$classes[] =  $data;
     		//echo "###".$user['id']  ."  ".  $codes2."###\n";
     	
     		$class = M('myclass')->where(["uid"=>$user['id'], "code2"=>$codes2])->find();
     		 
     		if(empty($class)){
     			M('myclass')->add($data);
     		}else{
     			//M('myclass')->add($data);
     		}
     		 
     		 
     	}
     	 

	 }
	 
	 
	 function recommendList(){
	 	$user = $this->check_user_token();
	 	
	 	$classes = M('myclass')->where(["uid"=>$user['id']])->select();
	 	$departs = M('myclass')->query("select count(*), depart from myclass where uid = {$user['id']} group by depart;");
	 	

	 	$departments = [];
	 	foreach($classes as $k=>$v){
	 		$ids[] = $v['cid'];
	 	}
	 	
	 	
	 	foreach ($departs as $k=>$v){
	 		$ds[] = $v['depart'];
	 		//echo "{$k}---";
	 		if($k >= 1)break;
	 	}
	 	
	    $ids_str = implode(",", $ids);
	    $ds_str = implode("','", $ds);
	//echo $ids_str;
	    $where = "id not in ($ids_str) and dept in ('$ds_str')";
	    
	    $list = M('class')->where($where)->page(1, 10)->order('rate desc')->select();
	    
	     
	    $recommand_classes = [];
	    foreach($list as $c){
	    	$class = $this->get_class_fields2($c);
	    	$recommand_classes[] = $class;
	    }
	    	
	    $this->outPut(0,"",  ["classes"=>$recommand_classes]);
	    exit;
	   
	 	
	 }
	 
	 
	 function classDetail(){
	 	$user = $this->check_user_token();
	 	$input = $this->getPostJson();
	 	$cid = 0;
	 	if(isset($input['id']))
	 		$cid = $input['id'];
	 	if($cid == 0){
	 		$this->outPut(1,"cid missing");
	 	}
	 	

	 	$class = $this->get_class_fields($cid);

	 	 
	 	$this->outPut(0,"",  ["classes"=>[$class]]);
	 	 
	 }
	 
	 
	 
	 function searchList(){
	 //	$user = $this->check_user_token();
	    $input = $this->getPostJson();
	    
	    $uri = $_SERVER["REQUEST_URI"];
	    $content =  file_get_contents ("php://input");
	    Log::info(" $uri $content ");
	    
	    $rank = "rate";
	    if($input['rank'] == "time")
	    	$rank = "time";
	    	
	    
	    $w = Date('w', time() - 15*3600);
	    $start = date('H', time() - 15*3600)*60+ date('i');
	    

	    
	    $mode = M('class');
	    $where = "";
	    if(!empty($input["department"])){
	    	$depart  = strtolower($input["department"]);
	    	$where = "LOWER(dept) = '{$depart}'";
	    }
	    
	    if(!empty($input["keyword"])){
	    	$keywords =strtolower( $input["keyword"]);
	    	if(empty($where))
	    		$where .=" LOWER(title)  like '%{$keywords}%' or   LOWER(codes)  like '%{$keywords}%' or LOWER(room) like '%{$keywords}%' or LOWER(teacher) like '%{$keywords}%'";
	    		 
	    		else
	    	$where .=" And ( LOWER(title)  like '%{$keywords}%' or   LOWER(codes)  like '%{$keywords}%' or LOWER(room) like '%{$keywords}%' or LOWER(teacher) like '%{$keywords}%' )";
	    }
	    
        $page = 1;
        if(isset($input['page']))
        	$page = $input['page'];
        
        if($rank == "rate"){
	    	$list = M('class')->where($where)->page(1, 100)->order('rate desc')->select();
	    
	    	foreach($list as $c){
	    		$class = $this->get_class_fields2($c);
	    		$classes[] = $class;
	    	}
	    	    	
	    	$this->outPut(0,"",  ["classes"=>$classes]);
	    	exit;
	    	
	    	
	    }
	  
	    
	    $list = M('class')->where($where)->page(1, 100)->select();
	    
	    
	    $classes = [];
	    $w = Date('w', time() - 15*3600);
	    
	    $class_map = [];
	    foreach($list as $k=>$v){
	    	$ids[] = $v['id'];
	    	$class_map[$v['id']] = $v;
	    }
	    $ids_string = implode(",", $ids);
	  //  echo $ids_string;
	    
	    
	    $list2 = M('class_time')->where("cid in($ids_string)")->select();
	    $time_rank;
	    $start_time = $w*1440+ $start;
	    //echo $start_time;
	    foreach($list2 as $k=>$v){
	    	$span = $v['start_time']  - $start_time;
	    	if($span < 0 ) $span += 1440*7;
	    	$list2[$k]["span"] = $span;	    	
	    }

// 	    $a = array(3, 2, 5, 6, 1);
	    
// 	    usort($a,  function($a, $b) { return($a > $b); });
	    
// 	    foreach ($a as $key => $value) {
// 	    	echo "$key: $value\n";
// 	    }

	    
	    usort($list2, function($a, $b) { return($a['span'] > $b['span']); });
	    $class_ids = [];
	    foreach($list2 as $k=>$v){
	    	//echo "{$v['span']}---\n";
	    	if(!in_array($v['cid'],$class_ids))
	    		$class_ids[] = $v['cid'];
	    }
	     
	    
//  var_dump($class_ids);
// 	    exit;
	    
	    foreach($class_ids as $cid){
            $c = $class_map[$cid];
	    	$class = $this->get_class_fields2($c);
	    	$classes[] = $class;
	    }

	 	 
	 	$this->outPut(0,"",  ["classes"=>$classes]);
	 	 
	 }
	 
	 
	 function testabc(){
	 	 $where =  "code2 = 34860";
	 	 $class = M('class')->where($where)->page(1, 10)->find();
	 	 
	 	 //var_dump($class['teacher']);
	 	 
	 	 $ch = curl_init();


	 	 $url = "https://www.google.com/#q=JAIN,+R.+uci+ratemyprofessors&*";
	 	 curl_setopt($ch, CURLOPT_URL,            $url );
	// 	 curl_setopt($ch, CURLOPT_POST,            1);
	 //	 curl_setopt($ch, CURLOPT_POSTFIELDS,     $raw );
	 	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	 	// curl_setopt($ch, CURLOPT_HEADER, true);
	 	 
	 	  
	 	 $comment =curl_exec ($ch);
	 	 
	 	 
	 	// $pos = strpos($comment, "b_results");
	 	 
	 	 

	 	 $result = substr($comment, $pos+14, 1000);
	 	// $uci_token = substr($comment, $pos+14, 64);
	 //	echo $result;

	 	// $uci_token_check = substr($comment, $pos+14, 6);
	 	// $uci_token = substr($comment, $pos+14, 64);
	 	 
	 	 
	 	// $content = file_get_contents($url);
	 	 echo $comment;
	 	 exit;
	 	
	 }
     
	 
	 function load_all_classes(){
	 	echo $argv[1];
	 	//echo "this is load_all_classes";
	 	
	 }
    
  

}