<?php 

namespace Common\Common;

class Firebase
{
	static $instance = NULL;
	
	protected  $_firebase = NULL;
	
	const DEFAULT_URL = 'https://chacha.firebaseio.com/';
	const DEFAULT_TOKEN = 'Pok0aef6K9Pvy0dOogBON93oeY69Sk0VTMdYvdLN';
	const DEFAULT_TODO_PATH = '/sample/todo';
	const DELETE_PATH = '/sample';
	const DEFAULT_SET_RESPONSE = '{"name":"Pick the milk","priority":1}';
	const DEFAULT_UPDATE_RESPONSE = '{"name":"Pick the beer","priority":2}';
	const DEFAULT_PUSH_RESPONSE = '{"name":"Pick the LEGO","priority":3}';
	const DEFAULT_DELETE_RESPONSE = 'null';
	const DEFAULT_URI_ERROR = 'You must provide a baseURI variable.';
	
	public static function getInstatnce(){
		Vendor("Firebase.FirebaseLib");
		if($instance == NULL){
			$instance = new Firebase(); 
			$instance->_firebase = new \Firebase\FirebaseLib(self::DEFAULT_URL, self::DEFAULT_TOKEN);
            return $instance;
		}
		return $instance;
		
	}
	
	public static function setData($path, $data)
	{
		self::getInstatnce()->_firebase->set($path, $data);
	}
	
	public static function set($path, $data)
	{
		self::getInstatnce()->_firebase->set($path, $data);
	}
	
	public static function push($path, $data)
	{
		self::getInstatnce()->_firebase->push($path, $data);
	}
}




?>