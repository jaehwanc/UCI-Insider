<?php
namespace Common\Common;

use Common\Common\Firebase;
use API1_1\Model\User;
use Aws\S3\S3Client;
use Common\Common\Log;

class Util
{
	static public function debug()
	{
	    $traces = debug_backtrace();
		
	    
	    foreach($traces as $line){
	    	
	    echo "{$line['class']}::{$line['function']}   {$line['file']}:: {$line['line']} ";
	    }
	  //  var_dump($traces);
	
	}
	
	static public function sendMsgFromAdmin($uid, $msg){
		$session = md5(md5($uid));
		$path = "messages/serivce_chat/{$session}";
		//$user = User::info(1);
		$time = time();
		$data = ["uid"=>"1", "body"=>$msg, "time"=>"$time"];
		Firebase::push($path, $data);
		
	}

	/**
	 * 空字符串转换为字符串
	 * @param $v  字符串
	 * @param $defaultValue 默认字符串值
	 * @return mixed
	 */
	public  static function nullToString($v,$defaultValue){
		if(empty($v)){
			return $defaultValue;
		}
		return $v;
	}

	/**
	 * @param $remoteIp
	 * @return string
	 */
	public static function remoteIpToString($remoteIp){
		$result=$remoteIp;
		if(empty($remoteIp)){
			$result="127.0.0.1";
			return $result;
		}else if(!empty($remoteIp)&&$remoteIp=='::1'){
			$result="127.0.0.1";
			return $result;
		}

		return $result;
	}

	/**
	 * @param $user_agent
	 * @return string
	 */
	 public static function deviceType($user_agent){
		$result='PC';
		$lowerUserAgent=strtolower($user_agent);
		if(empty($lowerUserAgent)){
			$result='PC';
		}else if(!empty($lowerUserAgent)&&stripos($lowerUserAgent,'android') !== false){
			$result='Android';
		}else if(!empty($lowerUserAgent)&&stripos($lowerUserAgent,'iphone') !== false){
			$result='iOS';
		}

		return $result;

	}
	
	
	public static function varify_token($product_id, $token){
		$access_token =  Util::get_access_token();
		$command = "curl https://www.googleapis.com/androidpublisher/v2/applications/com.exutech.chacha/purchases/products/{$product_id}/tokens/{$token}?access_token=$access_token";
		$result = shell_exec($command);
		$data = json_decode($result);
		return $data;
		
	}
	
	public static function get_access_token($reflesh = false){
		
		$time = time();
		$data = S("access_token");
		$diff = time() - $data['time'];
		$token = $data['token'];
		//var_dump($data);
		if($diff > 30*60  || $reflesh){
			
			$token = Util::get_new_access_token();
			S("access_token", ['time'=>$time, "token"=>$token]);
			return $token;
		}else{
			return $token;
		}
		
	}
	
	public static function  get_new_access_token(){
		$content =  file_get_contents("http://test.getchacha.com/examples/google.php");
		$command = "curl -d 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion={$content}' https://www.googleapis.com/oauth2/v4/token";
		$result = shell_exec($command);
		$data = json_decode($result);
		$access_token = $data->access_token;
		return $access_token;
		
	}
	
	// $filepath = "/Users/zhangyousong/chacha/Public/chacha.png";
	// $s3_name = /2016_01_02/chacha.png
	public static function s3_upload($filepath, $s3_name){
		$s3 = new \Aws\S3\S3Client([
				'version' => '2006-03-01',
				'region'  => 'us-west-1'
		]);
		
		$bucket = "chachaimg";

		$key = $s3_name;
	//	$key = "test.png";
		
		//echo "Creating a new object with key {$key}\n";
		$s3->putObject([
				'Bucket' => $bucket,
				'Key'    => $key,
				'SourceFile'   => $filepath,
				'ACL'    => 'public-read'
		]);
		
		return "http://img.getchacha.com/{$s3_name}";
	}
	
	public function sendPush($uid, $title, $body, $data, $sound = "", $collapse_key=""){

		$apiKey = "AIzaSyCcDoeb-GkzVtWZ0cLGeriTtzUU2ruI4CE";
		
		$path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
		
		$token = User::pushToken($uid);
		//echo $token;
		
		if(!empty($sound)){
			$fields = array(
					'to' => $token,
					"priority"=>"high",
					'collapse_key' => "call",
					"content_available"=>true,
					"Collapsible"=>true,
					'notification' => array('title' => $title, 'body' => $body, 'sound'=>$sound),
					'data' => $data
			);
			
		}else{
			$fields = array(
					'to' => $token,
					"priority"=>"high",
					'collapse_key' => "call",
					"content_available"=>true,
					"Collapsible"=>true,
					'notification' => array('title' => $title, 'body' => $body),
					'data' => $data
			);			
			
		}
		

		if(!empty($collapse_key)){
			$fields['collapse_key'] = $collapse_key;
		}
		

		$headers = array(
				'Authorization:key=' .  $apiKey,
				'Content-Type:application/json'
		);
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
		
		$result = curl_exec($ch);
		// var_dump($result);
		curl_close($ch);
		
		Log::info("sendPush   {$result}");
		
		return $result;
		
		
	}
	
	
	// only for chatpush
	public function sendPushAndroid($uid, $title, $body, $data){
	
		$apiKey = "AIzaSyCcDoeb-GkzVtWZ0cLGeriTtzUU2ruI4CE";
	
		$path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
	
		$token = User::pushToken($uid);
		//echo $token;
	
	
	
		$fields = array(
	//			'delay_while_idle'=>true,
				'to' => $token,
				'data' => $data,
				'time_to_live'=>15,
				
		);
	
		$headers = array(
				'Authorization:key=' .  $apiKey,
				'Content-Type:application/json'
		);
		$ch = curl_init();
	
		curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	
		$result = curl_exec($ch);
			
		curl_close($ch);
	
		//	echo $result;
	
	
	}
	
	public function getDynamicKey($uid, $room_id){
		
		$command = "node /usr/share/nginx/html/chacha/getkey.js  {$room_id}  {$uid}";
		
		Log::info("getDynamicKey   {$command}");
	//	echo $command;
		$result = exec($command);
		if(empty($result)) $result ="";
		return $result;
		
	}
	
	
	
	
	
	
}

?>