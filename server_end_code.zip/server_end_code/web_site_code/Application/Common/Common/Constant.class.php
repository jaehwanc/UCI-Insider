<?php

namespace Common\Common;

class Constant
{

    // 性别
    public static $CONSTSEX = array(
        "0" => "未知",
        "1" => "男",
        "2" => "女"
    );

    public static $PARTY_TYPE = array(
        "0" => "KTV",
        "1" => "休闲娱乐",
        "2" => "运动健身",
        "3" => "桌面游戏",
        "4" => "酒吧",
        "5" => "其他"
    );

    // 通过3SDK平台发送验证码的前缀
    public static $CHKCODE_PREFIX = '验证码:';

    //用户充值项目选择列表
    public static $AMOUNT_LISTS = array(
        '0' => array(
            'atype' => 0,
            'heartnum' => 1,
            'amount' => 1,
            'state' => ''
        ),
        '1' => array(
            'atype' => 1,
            'heartnum' => 6,
            'amount' => 5,
            'state' => '优惠10%'
        ),
        '2' => array(
            'atype' => 2,
            'heartnum' => 10,
            'amount' => 8,
            'state' => '优惠20%'
        )
    );

    // 返回结果信息
    public static $ERRORCODE = array(
        'OK' => array(
            'result' => 0,
            'message' => '成功'
        ),
        'NO' => array(
            'result' => 1,
            'message' => '失败'
        ),
        'PARAM' => array(
            'result' => 2,
            'message' => '请求异常，请稍后重试'//'请求参数错误'
        ),
        'SESSION' => array(
            'result' => 3,
            'message' => '你掉线了，请重新登录'
        ),
        'TEL_NOEXIST' => array(
            'result' => 4,
            'message' => '手机号未注册'
        ),
        'NAME_EXIST' => array(
            'result' => 5,
            'message' => '昵称已被占用'
        ),
        'LOGIN' => array(
            'result' => 6,
            'message' => '用户名或密码错误'
        ),
        'TEL_NOBIND' => array(
            'result' => 7,
            'message' => '初次使用，请完善个人信息'
        ),
        'TAG_EXIST' => array(
            'result' => 8,
            'message' => '标签已存在'
        ),
        'SMS_ERROR' => array(
            'result' => 9,
            'message' => '验证码有误，请重新输入'
        ),
        'SMS_EXPIRY' => array(
            'result' => 10,
            'message' => '验证码已过期，请重新获取'
        ),
        'HEART_LACK' => array(
            'result' => 11,
            'message' => '体力不足，需要补充体力'
        ),
        'PIC_MAX' => array(
            'result' => 12,
            'message' => '相册照片数量超过限制'
        ),
        'TAG_ISTAP' => array(
            'result' => 13,
            'message' => '已经评价过该标签！'
        ),
        'JU_ONLY' => array(
            'result' => 14,
            'message' => '已经有直播在身'
        ),
        'YY_ONLY' => array(
            'result' => 15,
            'message' => '你已经发布过预告'
        ),
        'BANNED' => array(
            'result' => 16,
            'message' => '你的账号因为一些原因已被封禁，申请解封请发邮件至hi@exutech.cn'
        ),
        'LOOKME' => array(
            'result' => 17,
            'message' => '不能关注自己'
        ),
        'LOOKLIKE' => array(
            'result' => 18,
            'message' => '播主已经收到你的想看愿望'
        ),
	'BADWORD' => array(
	    'result' =>19,
	    'message'=>'含有非法词汇'	
	),
	//2.1版新增返回值类型
        'BINDED' => array(
            'result' => 30,
            'message' => '该账号已绑定你的账户'
        ),
        'REDBACK_OPENED' => array(
            'result' => 20,
            'message' => '红包已领取'
        ),
        'REDBACK_ONLY' => array(
            'result' => 21,
            'message' => '指定红包须本人领取'
        ),
        'JB_LESS' => array(
            'result' => 22,
            'message' => '鲸币不足'
        ),
        'TX_LESS' => array(
            'result' => 23,
            'message' => '本月体现次数已用完'
        ),
        'YE_LESS' => array(
            'result' => 24,
            'message' => '余额不足提现'
        ),
        'TEL_LESS' => array(
            'result' => 25,
            'message' => '要绑定的手机号已占用'
        ),
        'WEIBO_LESS' => array(
            'result' => 26,
            'message' => '要绑定的微博账号已占用'
        ),
        'WEIXIN_LESS' => array(
            'result' => 27,
            'message' => '要绑定的微信账号已占用'
        ),
        'QQ_LESS' => array(
            'result' => 28,
            'message' => '要绑定的QQ账号已占用'
        ),
        'TX_HAVED' => array(
            'result' => 29,
            'message' => '已提交提现申请'
        ),
	'TEL_NEED' => array(
            'result' => 31,
            'message' => '未绑定手机号'
        ),
    );



    //直播状态
    public  static  $LIVE_STATUS = array(
        'LIVING'            => 0,  //正在直播
        'GENERATING_REPLAY' => 1,  //正在生成回放
        'HAD_REPLAY'        => 2,   //已经生成回放
    );
}

?>
