<?php

namespace Common\Common;

/**
 * 日志记录类，单列
 * 
 * @author wangshaoshuai
 *
 */
class Log
{


	private static $loginstance;

	/**
	 * 获取Logger实例
	 * @return Logger
	 */
	public static function getLogger()
	{
		Vendor('log4php.Logger');
		if (!isset($loginstance)) {
			\Logger::configure(C('LOG_DIR'));
			$loginstance = \Logger::getLogger('bluewhale');
		}
		
		return $loginstance;
	}
	
	public static function info($msg,$methodName=__METHOD__ ){
		$resultMsg=is_object($msg)||is_array($msg)?json_encode($msg):$msg;
		self::getLogger()->info($methodName."\t".$resultMsg);
	}

	static public function debug($break_point)
	{

		G($break_point);
		$processtime = G('begin', $break_point) * 1000;

		$logInfoMsg = sprintf("debug:{$break_point} processtime=%s", $processtime);
		LogUtil::getLogger()->info($logInfoMsg);

	}
	
	static public function debug2($break_point)
	{
	
		G($break_point);
		$processtime = G('begin', $break_point) * 1000;
	
		$logInfoMsg = sprintf("debug:{$break_point} processtime=%s", $processtime);
		echo $logInfoMsg."\n<br>";
		//LogUtil::getLogger()->info($logInfoMsg);
	
	}
	
	
	/**
	 * call function cache
	 */
	function pne_cache_call()
	{
		$arg_list = func_get_args();
		$lifetime = array_shift($arg_list);
		$rediskey = serialize($arg_list);
		$function = array_shift($arg_list);
      //  echo "$rediskey";
		if($lifetime == -1){
		$data =  call_user_func_array($function, $arg_list);
		return $data;
		}
		$data = S($rediskey);

		   if(empty($data)){
		   	$data =  call_user_func_array($function, $arg_list);
		   	if($lifetime == 0)
		   		S ($rediskey, $data);
		   		else
		     	S ($rediskey, $data, $lifetime);
		   }

        return $data;
	}
}