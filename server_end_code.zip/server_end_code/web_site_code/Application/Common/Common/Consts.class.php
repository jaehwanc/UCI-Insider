<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/6/6 0006
 * Time: 下午 4:26
 */

namespace Common\Common;


class Consts
{
    const SUCCESS = 0;
    const ERROR = 1;
    const PARAM_ERROR = 2;
    const TOKEN_ERROR = 3;
    const AGE_ERROR = 4;
    const NOT_GRAB_ID = 5;
    const BLOCKED = 6; 
    const OUT_OF_MONEY = 7;
    const TEACHER_OFFLINE = 8;
    const TEACHER_BUSY = 9;
    const Duplicate = 10;

    const CODE_DESC = [
        self::SUCCESS => 'success',
        self::ERROR => 'error',
        self::PARAM_ERROR => 'param error',
        self::TOKEN_ERROR => 'token invalid',
        self::AGE_ERROR => 'age must be >= 13',
        self::NOT_GRAB_ID => 'Id already registered',
    	self::BLOCKED => "you are blocked",
        self::OUT_OF_MONEY => "Student is out of money",
    	self::TEACHER_OFFLINE => 'Teacher is offline',
    	self::TEACHER_BUSY => 'Teacher is busy now',
    	self::Duplicate	=> "Duplicate"
    		
    ];

    const MALE = 1;
    const FEMALE = 2;
    const GENDER_DESC = [
        self::MALE => 'male',
        self::FEMALE => 'female',
    ];

    const UNLOCK_ACCOUNT = 0;
    const LOCK_ACCOUNT = 1;
    const LOCK_DESC = [
        self::UNLOCK_ACCOUNT => '账户正常',
        self::LOCK_ACCOUNT => '账户锁定',
    ];

    const AUDIT_PASS = 0;
    const AUDIT_NEED = 1;
    const AUDIT_NOT_PASS = 2;
    const AUDIT_DESC = [
        self::AUDIT_PASS => '已审核',
        self::AUDIT_NEED => '需审核',
        self::AUDIT_NOT_PASS => '审核失败',
    ];

    const REPORT_TYPE_UNFRIEND = 1;
    const REPORT_TYPE_FRIEND = 2;
    const REPORT_DESC = [
        self::REPORT_TYPE_UNFRIEND => '随机聊天',
        self::REPORT_TYPE_FRIEND => '好友发消息'
    ];

    const REPORT_AUDIT_WAIT_PASS = 0;
    const REPORT_AUDIT_NOT_PASS = 1;
    const REPORT_AUDIT_DESC = [
        self::REPORT_AUDIT_WAIT_PASS => '等待审核',
        self::REPORT_AUDIT_NOT_PASS => '已经审核'
    ];
}