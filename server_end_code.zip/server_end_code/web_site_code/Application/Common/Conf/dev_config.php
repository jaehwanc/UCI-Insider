<?php
$dev_config = array(
	//'配置项'=>'配置值'
	    'LOG_DIR' => "Application/Common/Conf/log4php.properties",
		'DB_TYPE' => 'mysql', // 数据库类型
		'DB_HOST' => '127.0.0.1', // 服务器地址
		'DB_NAME' => 'mocha', // 数据库名
		'DB_USER' => 'mocha', // 用户名
		'DB_PWD' => 'mochaisbest', // 密码
		'DB_PORT' => '3306', // 端口
		'DB_CHARSET' => 'utf8',
		
		
		//Redis缓存配置
		'DATA_CACHE_TIME' => 0,             //长连接时间,REDIS_PERSISTENT为1时有效
		'DATA_CACHE_PREFIX' => 'mocha_',            // 缓存前缀
		'DATA_CACHE_TYPE' => 'Redis',       //数据缓存类型
		'DATA_EXPIRE' => 0,               //数据缓存有效期(单位:秒) 0表示永久缓存
		'DATA_PERSISTENT' => 1,               //是否长连接
		//'DATA_REDIS_HOST'            =>  '10.171.91.195,10.171.91.195', //分布式Redis,默认第一个为主服务器
		'REDIS_HOST' => '127.0.0.1', //分布式Redis,默认第一个为主服务器
		'REDIS_PORT' => '6379',           //端口,如果相同只填一个,用英文逗号分隔
		'DATA_REDIS_AUTH' => '',    //Redis auth认证(密钥中不能有逗号),如果相同只填一个,用英文逗号分
        //facebook第三方登入配置参数
		'FACE_BOOK_APP_ID' => "1731966053712453",             //应用编号  1731966053712453
		'FACE_BOOK_APP_SECRET' => "45293250c5dcc67ad5116ba57975015b",             //应用密钥  45293250c5dcc67ad5116ba57975015b
		// node.js
		'NODE_SERVER'=>"http://test.getchacha.com:8888",
		
		'CURRENT_VERSION'=>'{"ios":{"version":"0.21","forece_update":true, "tips":"1.xxxx\n2.xxxxx" },"android":{"version":"20160905","forece_update":true, "tips":"1.xxxx\n2.xxxxx"}}',
		'BASE_URL' => 'http://54.199.248.50/chacha',//todo::不同的环境，要更改全base_url
		'ICON_ROOT_URL' => '/usr/share/nginx/html/chacha',

		//用户名字和密码
	    'USER_NAME' => '{"Ilovenanjingchacha":"87139881c77e90db5aea132bab6b2cb6",
	    "zhangyousongchacha":"ef54909a9d1815143b9e1d5e8bb366bb",
	    "taoshachacha":"0fb5fa2c523102f61e3d42412aec54af",
	    "yangxiaokangchacha":"857a412180df96a8bd58b0f59e59e3de",
	    "1111":"07e6e352d151e6a39cd819f6910f75af",
	    "liujingchacha":"aeae5daa2ddc6990d0d4fd87d4a68fb6", "aa":"b1a330367d14c606cd51eb9b842277e7"}',
		"USER_AUTH_GATEWAY" => "/Admin/Login"
);