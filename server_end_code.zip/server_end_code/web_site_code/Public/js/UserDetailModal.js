
/**
 * 全局函数。
 * 弹出用户的详细信息的modal
 * 调用方只需要传过来要显示详细信息的用户的uid即可
 * @param uid
 * @author sui
 * @date 2015-12-29
 */
function globalShowUserDetailFunction(uid) {
    var root_url=$("#backendRootUrl").val();
    var getUserDetailUrl = root_url+'/Article/getUserInfo?uid='+uid;
    //$ajax.get提交
    $.ajax({
        url: getUserDetailUrl,
        data: '',
        dataType: "json",
        type: "get",
        success: function (data) {
            var jsonObject = eval(data);
            //给modal赋值
            $("#userimg").attr("src", jsonObject.profilePicture);
            $("#uid").val(uid);
            $("#username strong").next().text(jsonObject.nickName);
            $("#unique_id strong").next().text(jsonObject.unique_id);
            $("#uuid strong").next().text(uid);
            $("#gender strong").next().text(jsonObject.gender == "1" ? "男" : "女");
            $("#createdAt strong").next().text(jsonObject.createdAt);
            $("#lastOnline strong").next().text(jsonObject.lastOnline);
            $("#loginMode strong").next().text(jsonObject.loginMode);
            $("#show strong").next().text(jsonObject.signature);
            $("#praiseCount strong").next().text(jsonObject.praiseCount);
            $("#fansCount strong").next().text(jsonObject.fansCount);
            $("#focusCount strong").next().text(jsonObject.focusCount);
            $("#liveCount strong").next().text(jsonObject.liveCount);
            $("#timeCount strong").next().text(jsonObject.timeCount);

            //是否被ban开关,因为不知道如果直接在switch开关事件之外获取开关的值，所以采取了赋值一个隐藏input的方法
            $("#banSwitchInUserDetailModalId").bootstrapSwitch('setState', jsonObject.banned == 0);
            $("#switchValId").val(jsonObject.banned);

            //记录旧的ban人状态，用于用户点击保存的时候比较新的ban人状态
            $("#oldBanStatusID").val(jsonObject.banned);

            //展示modal
            $("#userDetailModal").modal('show');
            return true;
        },
    });
}


/**
 * 保存按钮事件。保存用户当前选择的ban的数值
 * @author sui
 * @date 2015-12-29
 */
function updateUserBannedStatus(){
    var root_url        = $("#backendRootUrl").val();
    var touid           = $("#uid").val();
    var bannedStatus    = $("#switchValId").val();
    var oldBannedStatus = $("#oldBanStatusID").val();
    var banUserUrl      = root_url+'/Article/ban?id='+touid + "&bannedStat=" + bannedStatus;
    if( bannedStatus == oldBannedStatus){
        alert("啥也没改，你保存啥");
    } else{
        //$ajax.get提交
        $.ajax({
            url: banUserUrl,
            data: '',
            dataType: "json",
            type: "get",
            success: function (data) {
                var jsonObject = eval(data);
                if (jsonObject.status == 0) {
                    $("#oldBanStatusID").val(bannedStatus);
                    alert("成功");
                    return true;
                } else {
                    alert("失败");
                    return false;
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                //alert(XMLHttpRequest.status);
                //alert(XMLHttpRequest.readyState);
                //alert(textStatus);
            },
        });
    }


}


/**
 * 在用户详细信息modal里的ban开关事件
 * 用户详细信息modal的html文件在/public/html/UserDetailModal.html里。
 * 具体的控件id，和class请参考之。
 *
 * 由于html要先加载，之后再加载js，加载完jquery以及bootstrapSwitch之后才能绑定相应的事件，
 * 所以单独写出来一个js文件，在引用完所有相关文件之后再加载。
 *
 * 因为不知道如果直接在switch开关事件之外获取开关的值，所以采取了赋值一个隐藏input的方法
 *
 * @author sui
 * @date 2015-12-29
 */
$("#banSwitchInUserDetailModalId").on('switch-change', function (e, data) {
    var bannedStatus = data.value ? 0 : 1;
    $("#switchValId").val(bannedStatus);
});





