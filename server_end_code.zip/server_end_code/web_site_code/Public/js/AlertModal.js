window.alert = function(msg){
    $("#alertContentId").html(msg);
    $("#alertModalId").modal('show');
    setTimeout('$("#alertModalId").modal("hide")',1000);
};