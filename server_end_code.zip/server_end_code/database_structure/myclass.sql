# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.1.13-MariaDB)
# Database: mocha
# Generation Time: 2017-03-22 05:59:05 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table myclass
# ------------------------------------------------------------

DROP TABLE IF EXISTS `myclass`;

CREATE TABLE `myclass` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `depart` varchar(10) NOT NULL DEFAULT '',
  `uid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `code2` int(11) DEFAULT NULL,
  `quarter` int(11) DEFAULT NULL COMMENT '20161 ',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_code2` (`uid`,`code2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `myclass` WRITE;
/*!40000 ALTER TABLE `myclass` DISABLE KEYS */;

INSERT INTO `myclass` (`id`, `depart`, `uid`, `cid`, `code`, `code2`, `quarter`, `create_time`)
VALUES
	(61,'COMPSCI',6,601,225,34860,20171,'2017-03-19 12:19:45'),
	(62,'COMPSCI',6,609,260,34940,20171,'2017-03-19 12:19:45'),
	(63,'SYS',6,1735,240,37650,20171,'2017-03-19 12:19:45'),
	(64,'CSE',8,648,46,16160,20171,'2017-03-19 15:02:28'),
	(65,'COMPSCI',8,601,225,34860,20171,'2017-03-19 15:02:28'),
	(66,'COMPSCI',8,607,253,34920,20171,'2017-03-19 15:02:28');

/*!40000 ALTER TABLE `myclass` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
