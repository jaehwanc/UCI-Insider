# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.1.13-MariaDB)
# Database: mocha
# Generation Time: 2017-03-22 05:58:46 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table insider_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `insider_user`;

CREATE TABLE `insider_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uci_id` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL,
  `uci_token` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `class_update` int(11) DEFAULT NULL COMMENT '20161 2016年春天',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `uci_id` (`uci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `insider_user` WRITE;
/*!40000 ALTER TABLE `insider_user` DISABLE KEYS */;

INSERT INTO `insider_user` (`id`, `uci_id`, `name`, `token`, `uci_token`, `create_time`, `class_update`, `update_time`)
VALUES
	(6,'yoonkyus','Yoon Kyung Shon','aeb641d790f36609ccf0d324e75ed256','JB1nF1hMgWXqkd3pfTVZg9a2FUaPIKCictwIkDkrq8HBcBQhkB7rB7k7RkNqUfyX','2017-03-19 11:51:06',NULL,'2017-03-19 13:00:41'),
	(7,'yoonkyus1','UBLIC \"-//IETF//DTD HTML 2.0//EN\">\n<html><head>\n<title>400 Bad Request</title>\n</head><body>\n<h1>Bad','6cafe5e4b7a01375b8c91be836a696ac','no_key; path=/; domain=.uci.edu\r\nContent-Length: 4117\r\nContent-T','2017-03-19 12:53:17',NULL,'2017-03-19 12:53:17'),
	(8,'yousongz','Yousong Zhang','77ed57d9d9238d02d79f82f18da88f06','oS2tR25kZUU6nvBh7h5wMulkKeFzuiKJ1C2JvXTkHEhVZI2XQYjsiuCTz7iTgSs7','2017-03-19 15:02:23',NULL,'2017-03-19 15:17:02');

/*!40000 ALTER TABLE `insider_user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
